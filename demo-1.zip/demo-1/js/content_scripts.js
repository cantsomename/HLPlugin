var createElement = function (file) {
  if (!file) {
    return undefined;
  } else if (!file.fileName || !file.fileValue) {
    return undefined;
  }
  var patt = /[^.]*$/g;
  var filetype = patt.exec(file.fileName);
  var doc = null;
  if ("js" == filetype) {
    doc = document.createElement("script");
    doc.type = "text/javascript";
    doc.innerHTML = file.fileValue;
    doc.name = file.fileName;
  } else if ("css" == filetype) {
    doc = document.createElement("style");
    doc.rel = "stylesheet";
    doc.innerHTML = file.fileValue;
    doc.name = file.fileName;
  } else {
    return undefined;
  }
  return doc;
};
var createElements = function (files) {
  eles = [];
  for (i in files) {
    if (files[i]) {
      ele = createElement(files[i]);
      if (ele) {
        eles.push(ele);
      }
    }
  }
  return eles;
};

chrome.extension.onMessage.addListener(function (
  request,
  sender,
  sendResponse
) {
  var files = [];
  for (i in request) {
    if (typeof request[i] != "function")
      for (j in request[i]) {
        files.push(request[i][j]);
      }
  }
  var eles = createElements(files);
  rootEle = document.createElement("div");
  rootEle.id = "INJECTION";
  for (i in eles) {
    rootEle.append(eles[i]);
  }
  document.body.append(rootEle);
});
