function readJson(url){
    xml = new XMLHttpRequest();
    xml.open("GET",url,false);
    xml.send();
    jsonText = xml.responseText;
    return JSON.parse(jsonText);
}

function getFileValue(us){
    res = [];
    if(!us){
        return undefined;
    }
    for(i in us){
        filename = us[i];
        url = us[i];
        xml = new XMLHttpRequest();
        xml.open("GET",url,false);
        xml.send();
        res.push({fileName:filename,fileValue:xml.responseText});
    }
    return res;
}


var urls = readJson("resources/project.json");
var files = {
    js:getFileValue(urls.js),
    css:getFileValue(urls.css)
};




$(window).ready(function(){
    $("#work").click(function(){
        chrome.tabs.query({active:true,currentWindow:true},function(tabs){
            chrome.tabs.sendMessage(tabs[0].id,files);
        })
    });
});